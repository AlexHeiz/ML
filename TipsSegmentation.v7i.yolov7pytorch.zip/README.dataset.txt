# TipsSegmentation > 2024-06-27 2:56pm
https://universe.roboflow.com/7eleven/tipssegmentation

Provided by a Roboflow user
License: CC BY 4.0

